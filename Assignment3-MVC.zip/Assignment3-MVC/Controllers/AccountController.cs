﻿using Assignment3_MVC.Models;
using Company.data;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace Assignment3_MVC.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<ApplicationUsers> _UserManger;
        public AccountController(UserManager<ApplicationUsers> co)
        {
            _UserManger = co;
        }
        public IActionResult SignUp()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> SignUp(SignUpViewModel input)
        {
            if (ModelState.IsValid)
            {
                var user = new ApplicationUsers
                {
                    UserName = input.Email.Split("@")[0],
                };
                var result = await _UserManger.CreateAsync(user, input.Password);
                if (result.Succeeded)
                return RedirectToAction("SignIn");
              
                    foreach (var error in result.Errors)
                    {
                        ModelState.AddModelError("", error.Description);
                    }

            }
             return View();

            
        }
    }
}
